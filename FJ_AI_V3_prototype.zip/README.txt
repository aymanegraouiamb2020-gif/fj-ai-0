FJ AI V3 — prototype mobile
- Ouvrir index.html dans Safari.
- Déploiement statique possible sur Vercel.
- Les données affichées sont des données de démonstration.
- Pour un flux réel FinancialJuice, utiliser une intégration autorisée (RSS/widget/API) plutôt qu'un scraping non autorisé.
